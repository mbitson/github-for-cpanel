# github-for-cpanel
This repository is a work in progress.

A repository that allows cPanel users to install GitHub repos into their public web directory and auto-deploy updates on hooks.

Please note, this plugin will install the following on your server if it is not already installed:
Git
Composer
