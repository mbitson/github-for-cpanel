#!/bin/bash
# Uninstall script for GitHub for cPanel plugin.

rm -fR /usr/local/cpanel/base/frontend/paper_lantern/github_for_cpanel